<?php
   setcookie("user","",time()-1);
     header('location:index.php');
?>