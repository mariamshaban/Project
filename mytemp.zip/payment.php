<?php 
	ob_start();
  	session_start();
	if(!isset($_SESSION['user'])){
		header("location:index.php");
		die();
			}
	?>
<?php include "headerbefore.php"?>
<br/> <br/> <br/>

<center>

<table class="table">

<thead class="thead-dark">
<tr> 
    <th colspan="5" style="text-align:center"><h3><b> Your Cart Deatails</b></h3> </th>
</tr>
<tr> 
<th colspan="5" style="text-align:"><h3><b>
Order Number : 
<?php
    include"Connection.php"; 
    $db=new Connection();
    $sql="select max(OrderNo)+1 as OrderNo from `order` where username = '$_SESSION[user]'";
    $qry=mysqli_query($conn,$sql);
    if($row=mysqli_fetch_assoc($qry))
    {
        echo("<input type='text' readonly value='$row[OrderNo]' name='orderno'>"); 
        
    }
    else
    echo("1"); 
     ?>
</b></h3> </th>
</tr>
    <tr style="background-color:black;color:white;font-style:bold">
        <th> Item no</th>
        <th> Item Name</th>
        <th> Item Price</th>
        <th> Quantity</th>
        <th> Total</th>
    </tr>
   
</thead>
<?php

$db=new Connection();
$sql="select Itemno,ItemName,sum(Quantity) as Quantity,Price,sum(Subtotal) as Subtotal,Username from cart where username = '$_SESSION[user]' group by Itemno,ItemName,Price,Subtotal,Username";
$qry=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($qry))
{
 
?>
<tr>

<td><?php echo($row['Itemno']); ?> </td>
<td><?php echo($row['ItemName']); ?> </td>

<td><?php echo($row['Price']); ?> </td>
<td><?php echo($row['Quantity']); ?> </td>
<td><?php echo($row['Subtotal']); ?> </td>

</tr>

 
<?php } ?>
<tr style="background-color:black;color:white">
<td colspan="5"></td>
</tr>
<tr>
<td colspan="5" style="text-align:center"><h3><b>
 Total Of order :

<?php
 
$db=new Connection();
$sql="select sum(Subtotal) as Subtotal,Username from cart where username = '$_SESSION[user]' group by Username";
$qry=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($qry))
{
    echo("<input type='text' value='$row[Subtotal]' readonly name='orderno'>"); 
     
  } ?>

</b></h3>
</td>

</tr>
<td colspan="5" style="text-align:center"><h3><b>
<input type="submit" name="saveorder" value="Save Order" />

</td>
</table>








<br/> <br/> <br/>
<?php include "footer.php"?>